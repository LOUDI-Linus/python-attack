"""
@file:   mod02.py
@author: linuxzhen520@163.com
@date:   2019/12/29
@desc:
"""

def show():
    print("mod02.show")


if __name__ == "__main__":
    show()